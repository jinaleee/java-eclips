package day3.com.dao;


public class Calc {
	// 접근지시자 : process
	// process 메소드 생성
	// 매개변수 : int형 데이터 1개
	// 리턴타입 : int
	// 리턴 값 : 매개변수로 받은 값의 제곱
	
	public int process(int num){
		return (num*num);
	}
	
}//class
