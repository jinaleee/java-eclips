package day3.com.dao;

public class GuGuDan {
	
	public String process(int x, int y) {
		return x + " * "+ y +" = " + (x*y);
	}
	
}
